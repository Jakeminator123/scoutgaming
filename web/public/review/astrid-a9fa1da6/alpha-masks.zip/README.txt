Astrid a9fa1da6: 73 masks at 24 fps, 1280 x 720. 0001.png pairs with source frame zero. White keeps the pixel; black removes it. Includes Astrid and the original card.
